/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","eu",{button:"Txertatu kode zatia",codeContents:"Kode edukia",emptySnippetError:"Kode zatiak ezin du hutsik egon.",language:"Lengoaia",title:"Kode zatia",pathName:"kode zatia"});